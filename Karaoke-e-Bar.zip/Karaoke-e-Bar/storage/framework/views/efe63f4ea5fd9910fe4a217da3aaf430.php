<?php $__env->startSection('titulo', 'Formulário de Usuários'); ?>
<?php $__env->startSection('conteudo'); ?>
    <?php
        if (!empty($data->id)) {
            $action = route('usuario.update', $data->id);
        } else {
            $action = route('usuario.store');
        }

        $tipos = ['Cliente', 'Funcionário'];
    ?>

    <h3 class="titulo mb-4"><?php echo e(!empty($data->id) ? 'Edite o' : 'Cadastre o'); ?> <span>Usuário</span></h3>

    <div class="cartao col-12 col-lg-8 mx-auto">
        <div class="cartao-topo">Preencha o formulário do usuário</div>
        <div class="cartao-corpo">
            <form action="<?php echo e($action); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php if(!empty($data->id)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>

                <div class="row g-3">
                    <div class="col-12">
                        <label for="nome">Nome</label>
                        <input type="text" name="nome" id="nome" class="form-control"
                            value="<?php echo e(old('nome', $data->nome ?? '')); ?>">
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="cpf">CPF</label>
                        <input type="text" name="cpf" id="cpf" class="form-control" placeholder="000.000.000-00"
                            value="<?php echo e(old('cpf', $data->cpf ?? '')); ?>">
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="data_nascimento">Data de nascimento</label>
                        <input type="date" name="data_nascimento" id="data_nascimento" class="form-control"
                            value="<?php echo e(old('data_nascimento', !empty($data->id) ? $data->data_nascimento->format('Y-m-d') : '')); ?>">
                    </div>
                    <div class="col-12">
                        <label for="endereco">Endereço</label>
                        <input type="text" name="endereco" id="endereco" class="form-control"
                            value="<?php echo e(old('endereco', $data->endereco ?? '')); ?>">
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="telefone">Telefone</label>
                        <input type="text" name="telefone" id="telefone" class="form-control"
                            value="<?php echo e(old('telefone', $data->telefone ?? '')); ?>">
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="email">E-mail</label>
                        <input type="email" name="email" id="email" class="form-control"
                            value="<?php echo e(old('email', $data->email ?? '')); ?>">
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="senha">Senha</label>
                        <input type="password" name="senha" id="senha" class="form-control">
                        <?php if(!empty($data->id)): ?>
                            <small>Deixe em branco para manter a senha atual</small>
                        <?php endif; ?>
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="tipo">Tipo</label>
                        <select name="tipo" id="tipo" class="form-select">
                            <option value="">Selecione</option>
                            <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tipo); ?>"
                                    <?php echo e(old('tipo', $data->tipo ?? '') == $tipo ? 'selected' : ''); ?>>
                                    <?php echo e($tipo); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="d-flex justify-content-center gap-3 mt-4">
                    <a href="<?php echo e(url('usuario')); ?>" class="btn btn-indigo">Voltar</a>
                    <button type="submit" class="btn btn-violeta">Salvar</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ellen\Desktop\karaoke_grupo\resources\views/usuario/form.blade.php ENDPATH**/ ?>