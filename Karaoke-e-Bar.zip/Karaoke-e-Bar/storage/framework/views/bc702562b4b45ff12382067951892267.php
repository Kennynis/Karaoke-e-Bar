<?php $__env->startSection('titulo', 'Formulário de Reservas'); ?>
<?php $__env->startSection('conteudo'); ?>
    <?php
        if (!empty($data->id)) {
            $action = route('reserva.update', $data->id);
        } else {
            $action = route('reserva.store');
        }

        $listaStatus = ['Pendente', 'Confirmada', 'Cancelada'];
    ?>

    <h3 class="titulo mb-4"><?php echo e(!empty($data->id) ? 'Edite a' : 'Cadastre a'); ?> <span>Reserva</span></h3>

    <div class="cartao col-12 col-lg-8 mx-auto">
        <div class="cartao-topo">Preencha o formulário da reserva</div>
        <div class="cartao-corpo">
            <form action="<?php echo e($action); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php if(!empty($data->id)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>

                <div class="row g-3">
                    <div class="col-12 col-md-6">
                        <label for="usuario_id">Cliente</label>
                        <select name="usuario_id" id="usuario_id" class="form-select">
                            <option value="">Selecione</option>
                            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($usuario->id); ?>"
                                    <?php echo e(old('usuario_id', $data->usuario_id ?? '') == $usuario->id ? 'selected' : ''); ?>>
                                    <?php echo e($usuario->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="sala_id">Sala</label>
                        <select name="sala_id" id="sala_id" class="form-select">
                            <option value="">Selecione</option>
                            <?php $__currentLoopData = $salas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sala): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sala->id); ?>"
                                    <?php echo e(old('sala_id', $data->sala_id ?? '') == $sala->id ? 'selected' : ''); ?>>
                                    <?php echo e($sala->id); ?> - <?php echo e($sala->tipo); ?> (até <?php echo e($sala->capacidade); ?> pessoas)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label for="playlist_id">Playlist</label>
                        <select name="playlist_id" id="playlist_id" class="form-select">
                            <option value="">Selecione</option>
                            <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($playlist->id); ?>"
                                    <?php echo e(old('playlist_id', $data->playlist_id ?? '') == $playlist->id ? 'selected' : ''); ?>>
                                    <?php echo e($playlist->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small>Aparecem só as playlists que não estão em outra reserva</small>
                    </div>
                    <div class="col-12 col-md-4">
                        <label for="data_reserva">Data</label>
                        <input type="date" name="data_reserva" id="data_reserva" class="form-control"
                            value="<?php echo e(old('data_reserva', !empty($data->id) ? $data->data_reserva->format('Y-m-d') : '')); ?>">
                    </div>
                    <div class="col-12 col-md-4">
                        <label for="horario_inicio">Início</label>
                        <input type="time" name="horario_inicio" id="horario_inicio" class="form-control"
                            value="<?php echo e(old('horario_inicio', !empty($data->id) ? substr($data->horario_inicio, 0, 5) : '')); ?>">
                    </div>
                    <div class="col-12 col-md-4">
                        <label for="horario_fim">Fim</label>
                        <input type="time" name="horario_fim" id="horario_fim" class="form-control"
                            value="<?php echo e(old('horario_fim', !empty($data->id) ? substr($data->horario_fim, 0, 5) : '')); ?>">
                    </div>
                    <div class="col-12 col-md-4">
                        <label for="quantidade_pessoas">Quantidade de pessoas</label>
                        <input type="number" name="quantidade_pessoas" id="quantidade_pessoas" class="form-control"
                            value="<?php echo e(old('quantidade_pessoas', $data->quantidade_pessoas ?? '')); ?>">
                    </div>
                    <div class="col-12 col-md-4">
                        <label for="status">Status</label>
                        <select name="status" id="status" class="form-select">
                            <option value="">Selecione</option>
                            <?php $__currentLoopData = $listaStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status); ?>"
                                    <?php echo e(old('status', $data->status ?? '') == $status ? 'selected' : ''); ?>>
                                    <?php echo e($status); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-12 col-md-4 d-flex align-items-end">
                        <div class="form-check mb-2">
                            <input type="checkbox" name="menor_presente" id="menor_presente" class="form-check-input"
                                value="1"
                                <?php echo e(old('menor_presente', $data->menor_presente ?? false) ? 'checked' : ''); ?>>
                            <label for="menor_presente" class="form-check-label">Haverá menores de idade</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <label for="motivo_cancelamento">Motivo do cancelamento</label>
                        <input type="text" name="motivo_cancelamento" id="motivo_cancelamento" class="form-control"
                            value="<?php echo e(old('motivo_cancelamento', $data->motivo_cancelamento ?? '')); ?>">
                        <small>Preencha somente se o status for Cancelada</small>
                    </div>
                </div>

                <div class="d-flex justify-content-center gap-3 mt-4">
                    <a href="<?php echo e(url('reserva')); ?>" class="btn btn-indigo">Voltar</a>
                    <button type="submit" class="btn btn-violeta">Salvar</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ellen\Desktop\karaoke_grupo\resources\views/reserva/form.blade.php ENDPATH**/ ?>