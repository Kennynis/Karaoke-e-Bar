<?php $__env->startSection('titulo', 'Listagem de Produtos'); ?>
<?php $__env->startSection('conteudo'); ?>
    <h3 class="titulo mb-4">Nossos <span>Produtos</span></h3>

    <div class="cartao">
        <div class="cartao-topo">Listagem de produtos</div>
        <div class="cartao-corpo">
            <form action="<?php echo e(route('produto.search')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row g-3 align-items-end">
                    <div class="col-12 col-md-3">
                        <label for="tipo">Buscar por</label>
                        <select name="tipo" id="tipo" class="form-select">
                            <option value="nome">Nome</option>
                            <option value="categoria">Categoria</option>
                        </select>
                    </div>
                    <div class="col-12 col-md-5">
                        <label for="valor">Valor</label>
                        <input type="text" name="valor" id="valor" placeholder="Pesquisar..." class="form-control">
                    </div>
                    <div class="col-12 col-md-4 d-flex gap-2">
                        <button type="submit" class="btn btn-violeta">Buscar</button>
                        <a href="<?php echo e(url('produto/create')); ?>" class="btn btn-indigo">Novo</a>
                    </div>
                </div>
            </form>

            <div class="table-responsive mt-4">
                <table class="table table-striped table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Imagem</th>
                            <th scope="col">Nome</th>
                            <th scope="col">Categoria</th>
                            <th scope="col">Preço</th>
                            <th scope="col">Alcoólico</th>
                            <th scope="col">Estoque</th>
                            <th scope="col">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope='row'><?php echo e($item->id); ?></th>
                                <td>
                                    <?php if($item->imagem): ?>
                                        <img src="<?php echo e(asset('storage/' . $item->imagem)); ?>" class="miniatura"
                                            alt="<?php echo e($item->nome); ?>">
                                    <?php else: ?>
                                        <span class="sem-imagem">Sem imagem</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->nome); ?></td>
                                <td><?php echo e($item->categoria); ?></td>
                                <td class="text-nowrap">R$ <?php echo e(number_format($item->preco, 2, ',', '.')); ?></td>
                                <td><?php echo e($item->alcoolico ? 'Sim' : 'Não'); ?></td>
                                <td><?php echo e($item->estoque); ?></td>
                                <td>
                                    <div class="d-flex gap-2">
                                        <a class='btn btn-indigo btn-sm' title='Editar'
                                            href="<?php echo e(route('produto.edit', $item->id)); ?>">Editar</a>
                                        <form action="<?php echo e(route('produto.destroy', $item->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class='btn btn-violeta btn-sm' title='Excluir'
                                                onclick="return confirm('Deseja Excluir?')">Deletar</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ellen\Desktop\karaoke_grupo\resources\views/produto/list.blade.php ENDPATH**/ ?>