<?php $__env->startSection('titulo', 'Formulário de Compras'); ?>
<?php $__env->startSection('conteudo'); ?>
    <?php
        if (!empty($data->id)) {
            $action = route('compra.update', $data->id);
        } else {
            $action = route('compra.store');
        }
    ?>

    <h3 class="titulo mb-4"><?php echo e(!empty($data->id) ? 'Edite a' : 'Cadastre a'); ?> <span>Compra</span></h3>

    <div class="cartao col-12 col-lg-8 mx-auto">
        <div class="cartao-topo">Preencha o formulário da compra</div>
        <div class="cartao-corpo">
            <form action="<?php echo e($action); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php if(!empty($data->id)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>

                <div class="row g-3">
                    <div class="col-12 col-md-6">
                        <label for="usuario_id">Cliente</label>
                        <select name="usuario_id" id="usuario_id" class="form-select">
                            <option value="">Selecione</option>
                            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($usuario->id); ?>"
                                    <?php echo e(old('usuario_id', $data->usuario_id ?? '') == $usuario->id ? 'selected' : ''); ?>>
                                    <?php echo e($usuario->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="data_compra">Data</label>
                        <input type="date" name="data_compra" id="data_compra" class="form-control"
                            value="<?php echo e(old('data_compra', !empty($data->id) ? $data->data_compra->format('Y-m-d') : '')); ?>">
                    </div>
                </div>

                <div class="table-responsive mt-4">
                    <table class="table table-striped align-middle mb-0">
                        <thead>
                            <tr>
                                <th scope="col">Produto</th>
                                <th scope="col">Preço</th>
                                <th scope="col">Estoque</th>
                                <th scope="col">Quantidade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($produto->nome); ?></td>
                                    <td class="text-nowrap">R$ <?php echo e(number_format($produto->preco, 2, ',', '.')); ?></td>
                                    <td><?php echo e($produto->estoque); ?></td>
                                    <td>
                                        <input type="number" min="0" name="itens[<?php echo e($produto->id); ?>]"
                                            class="form-control campo-quantidade" aria-label="Quantidade de <?php echo e($produto->nome); ?>"
                                            value="<?php echo e(old('itens.' . $produto->id, $quantidades[$produto->id] ?? '')); ?>">
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="d-flex justify-content-center gap-3 mt-4">
                    <a href="<?php echo e(url('compra')); ?>" class="btn btn-indigo">Voltar</a>
                    <button type="submit" class="btn btn-violeta">Salvar</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ellen\Desktop\karaoke_grupo\resources\views/compra/form.blade.php ENDPATH**/ ?>