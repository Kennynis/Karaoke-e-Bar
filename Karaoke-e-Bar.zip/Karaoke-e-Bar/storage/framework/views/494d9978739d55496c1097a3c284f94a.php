<!doctype html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('titulo', 'Karaokê & Bar'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bitter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
</head>

<body class="d-flex flex-column min-vh-100">
    <!-- Sidebar -->
    <?php echo $__env->make('sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="container flex-grow-1 py-4">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button class="btn-close" data-bs-dismiss="alert" aria-label="fechar"></button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button class="btn-close" data-bs-dismiss="alert" aria-label="fechar"></button>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <b>Por favor, verifique os erros abaixo</b>
                <ul class="mb-0 mt-1">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <button class="btn-close" data-bs-dismiss="alert" aria-label="fechar"></button>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('conteudo'); ?>
    </main>

    <footer class="rodape text-center">
        <div class="d-flex justify-content-center flex-wrap gap-4 py-4 px-3">
            <a href="<?php echo e(url('/')); ?>">Início</a>
            <a href="<?php echo e(url('sala')); ?>">Salas</a>
            <a href="<?php echo e(url('reserva')); ?>">Reservas</a>
            <a href="<?php echo e(url('playlist')); ?>">Playlists</a>
            <a href="<?php echo e(url('produto')); ?>">Produtos</a>
            <a href="<?php echo e(url('compra')); ?>">Compras</a>
            <a href="<?php echo e(url('usuario')); ?>">Usuários</a>
        </div>
        <div class="rodape-copia">© 2026 Karaokê &amp; Bar. Todos os direitos reservados.</div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\Users\Ellen\Desktop\karaoke_grupo\resources\views/main.blade.php ENDPATH**/ ?>