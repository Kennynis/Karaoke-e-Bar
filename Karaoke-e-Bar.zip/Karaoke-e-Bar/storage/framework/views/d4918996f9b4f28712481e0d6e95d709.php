<?php $__env->startSection('conteudo'); ?>
    <div class="text-center py-5">
        <h1 class="chamada">cante a <span>SUA</span> Playlist</h1>
        <p class="col-md-8 mx-auto mt-4">O lugar perfeito para reunir amigos, cantar suas músicas favoritas e criar
            momentos inesquecíveis.</p>
        <hr class="col-md-8 mx-auto my-5">
        <a href="<?php echo e(url('sala')); ?>" class="btn btn-violeta">Ver as salas</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ellen\Desktop\karaoke_grupo\resources\views/home.blade.php ENDPATH**/ ?>