<?php $__env->startSection('titulo', 'Listagem de Reservas'); ?>
<?php $__env->startSection('conteudo'); ?>
    <h3 class="titulo mb-4">Nossas <span>Reservas</span></h3>

    <div class="cartao">
        <div class="cartao-topo">Listagem de reservas</div>
        <div class="cartao-corpo">
            <form action="<?php echo e(route('reserva.search')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row g-3 align-items-end">
                    <div class="col-12 col-md-3">
                        <label for="tipo">Buscar por</label>
                        <select name="tipo" id="tipo" class="form-select">
                            <option value="usuario">Cliente</option>
                            <option value="playlist">Playlist</option>
                            <option value="data_reserva">Data (aaaa-mm-dd)</option>
                            <option value="status">Status</option>
                        </select>
                    </div>
                    <div class="col-12 col-md-5">
                        <label for="valor">Valor</label>
                        <input type="text" name="valor" id="valor" placeholder="Pesquisar..." class="form-control">
                    </div>
                    <div class="col-12 col-md-4 d-flex gap-2">
                        <button type="submit" class="btn btn-violeta">Buscar</button>
                        <a href="<?php echo e(url('reserva/create')); ?>" class="btn btn-indigo">Novo</a>
                    </div>
                </div>
            </form>

            <div class="table-responsive mt-4">
                <table class="table table-striped table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Cliente</th>
                            <th scope="col">Sala</th>
                            <th scope="col">Playlist</th>
                            <th scope="col">Data</th>
                            <th scope="col">Horário</th>
                            <th scope="col">Pessoas</th>
                            <th scope="col">Menores</th>
                            <th scope="col">Status</th>
                            <th scope="col">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope='row'><?php echo e($item->id); ?></th>
                                <td><?php echo e($item->usuario->nome); ?></td>
                                <td class="text-nowrap"><?php echo e($item->sala->id); ?> - <?php echo e($item->sala->tipo); ?></td>
                                <td><?php echo e($item->playlist->nome ?? 'Sem playlist'); ?></td>
                                <td><?php echo e($item->data_reserva->format('d/m/Y')); ?></td>
                                <td class="text-nowrap"><?php echo e(substr($item->horario_inicio, 0, 5)); ?> às <?php echo e(substr($item->horario_fim, 0, 5)); ?></td>
                                <td><?php echo e($item->quantidade_pessoas); ?></td>
                                <td><?php echo e($item->menor_presente ? 'Sim' : 'Não'); ?></td>
                                <td><?php echo e($item->status); ?></td>
                                <td>
                                    <div class="d-flex gap-2">
                                        <a class='btn btn-indigo btn-sm' title='Editar'
                                            href="<?php echo e(route('reserva.edit', $item->id)); ?>">Editar</a>
                                        <form action="<?php echo e(route('reserva.destroy', $item->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class='btn btn-violeta btn-sm' title='Excluir'
                                                onclick="return confirm('Deseja Excluir?')">Deletar</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ellen\Desktop\karaoke_grupo\resources\views/reserva/list.blade.php ENDPATH**/ ?>