<nav class="navbar navbar-expand-lg topo" style="height: 85px; background-color: #f5f2fc;">
  <div class="container-fluid px-3">
    <a class="navbar-brand d-flex" href="<?php echo e(url('/')); ?>">
      <img src="<?php echo e(asset('imagens/logo.png')); ?>"
           alt="Karaokê &amp; Bar"
           style="width: 170px; height: 500px; object-fit: contain; margin-bottom: 6px; ">
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
      <ul class="navbar-nav mx-auto align-items-center">
        <li class="nav-item align-items-center">
          <a class="nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>">Início</a>
        </li>
        <li class="nav-item align-items-center">
          <a class="nav-link <?php echo e(request()->is('sala*') ? 'active' : ''); ?>" href="<?php echo e(url('sala')); ?>">Salas</a>
        </li>
        <li class="nav-item align-items-center">
          <a class="nav-link <?php echo e(request()->is('reserva*') ? 'active' : ''); ?>" href="<?php echo e(url('reserva')); ?>">Reservas</a>
        </li>
        <li class="nav-item align-items-center">
          <a class="nav-link <?php echo e(request()->is('playlist*') ? 'active' : ''); ?>" href="<?php echo e(url('playlist')); ?>">Playlists</a>
        </li>
        <li class="nav-item align-items-center">
          <a class="nav-link <?php echo e(request()->is('produto*') ? 'active' : ''); ?>" href="<?php echo e(url('produto')); ?>">Produtos</a>
        </li>
        <li class="nav-item align-items-center">
          <a class="nav-link <?php echo e(request()->is('compra*') ? 'active' : ''); ?>" href="<?php echo e(url('compra')); ?>">Compras</a>
        </li>
        <li class="nav-item align-items-center">
          <a class="nav-link <?php echo e(request()->is('usuario*') ? 'active' : ''); ?>" href="<?php echo e(url('usuario')); ?>">Usuários</a>
        </li>
      </ul>
    </div>
  </div>
</nav><?php /**PATH C:\Users\Ellen\Desktop\karaoke_grupo\resources\views/sidebar.blade.php ENDPATH**/ ?>