<?php $__env->startSection('titulo', 'Formulário de Salas'); ?>
<?php $__env->startSection('conteudo'); ?>
    <?php
        if (!empty($data->id)) {
            $action = route('sala.update', $data->id);
        } else {
            $action = route('sala.store');
        }

        $tipos = ['Pequena', 'Média', 'Grande'];
        $listaStatus = ['Disponível', 'Ocupada', 'Manutenção'];
    ?>

    <h3 class="titulo mb-4"><?php echo e(!empty($data->id) ? 'Edite a' : 'Cadastre a'); ?> <span>Sala</span></h3>

    <div class="cartao col-12 col-lg-8 mx-auto">
        <div class="cartao-topo">Preencha o formulário da sala</div>
        <div class="cartao-corpo">
            <form action="<?php echo e($action); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php if(!empty($data->id)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>

                <input type="hidden" name="id" value="<?php echo e(old('id', $data->id ?? '')); ?>">
                <div class="row g-3">
                    <div class="col-12 col-md-6">
                        <label for="tipo">Tipo</label>
                        <select name="tipo" id="tipo" class="form-select">
                            <option value="">Selecione</option>
                            <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tipo); ?>"
                                    <?php echo e(old('tipo', $data->tipo ?? '') == $tipo ? 'selected' : ''); ?>>
                                    <?php echo e($tipo); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="capacidade">Capacidade</label>
                        <input type="number" name="capacidade" id="capacidade" class="form-control"
                            value="<?php echo e(old('capacidade', $data->capacidade ?? '')); ?>">
                        <small>Pequena até 5, Média até 12, Grande até 25</small>
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="preco_hora">Preço por hora</label>
                        <input type="number" step="0.01" name="preco_hora" id="preco_hora" class="form-control"
                            value="<?php echo e(old('preco_hora', $data->preco_hora ?? '')); ?>">
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="status">Status</label>
                        <select name="status" id="status" class="form-select">
                            <option value="">Selecione</option>
                            <?php $__currentLoopData = $listaStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status); ?>"
                                    <?php echo e(old('status', $data->status ?? '') == $status ? 'selected' : ''); ?>>
                                    <?php echo e($status); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="d-flex justify-content-center gap-3 mt-4">
                    <a href="<?php echo e(url('sala')); ?>" class="btn btn-indigo">Voltar</a>
                    <button type="submit" class="btn btn-violeta">Salvar</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ellen\Desktop\karaoke_grupo\resources\views/sala/form.blade.php ENDPATH**/ ?>