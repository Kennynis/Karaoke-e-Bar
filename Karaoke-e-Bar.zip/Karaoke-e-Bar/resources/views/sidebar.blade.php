<nav class="navbar navbar-expand-lg topo" style="height: 85px; background-color: #f5f2fc;">
  <div class="container-fluid px-3">
    <a class="navbar-brand d-flex" href="{{ url('/') }}">
      <img src="{{ asset('imagens/logo.png') }}"
           alt="Karaokê &amp; Bar"
           style="width: 170px; height: 500px; object-fit: contain; margin-bottom: 6px; ">
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
      <ul class="navbar-nav mx-auto align-items-center">
        <li class="nav-item align-items-center">
          <a class="nav-link {{ request()->is('/') ? 'active' : '' }}" href="{{ url('/') }}">Início</a>
        </li>
        <li class="nav-item align-items-center">
          <a class="nav-link {{ request()->is('sala*') ? 'active' : '' }}" href="{{ url('sala') }}">Salas</a>
        </li>
        <li class="nav-item align-items-center">
          <a class="nav-link {{ request()->is('reserva*') ? 'active' : '' }}" href="{{ url('reserva') }}">Reservas</a>
        </li>
        <li class="nav-item align-items-center">
          <a class="nav-link {{ request()->is('playlist*') ? 'active' : '' }}" href="{{ url('playlist') }}">Playlists</a>
        </li>
        <li class="nav-item align-items-center">
          <a class="nav-link {{ request()->is('produto*') ? 'active' : '' }}" href="{{ url('produto') }}">Produtos</a>
        </li>
        <li class="nav-item align-items-center">
          <a class="nav-link {{ request()->is('compra*') ? 'active' : '' }}" href="{{ url('compra') }}">Compras</a>
        </li>
        <li class="nav-item align-items-center">
          <a class="nav-link {{ request()->is('usuario*') ? 'active' : '' }}" href="{{ url('usuario') }}">Usuários</a>
        </li>
      </ul>
    </div>
  </div>
</nav>